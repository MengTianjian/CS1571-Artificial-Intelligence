# CS1571-Artificial-Intelligence
Python version: 2.7.13  
Libraries used: sys, heapq, math, Queue, copy  
Additional resource: Stuart Russell and Peter Norvig. 2010. Artificial Intelligence: a Modern Approach. 3rd Ed.  
Person discussed: TA Ahmed Magooda  
