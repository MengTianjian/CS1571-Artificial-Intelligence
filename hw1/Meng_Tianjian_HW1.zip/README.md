# CS1571-Artificial-Intelligence
Python version: 2.7.13  
Libraries used: sys, heapq, math, Queue, copy  
Additional resource: Stuart Russell and Peter Norvig. 2010. Artificial Intelligence: a Modern Approach. 3rd Ed.  
Person discussed: TA Ahmed Magooda  

Problem: The test case TA gave us didn't have a consistent format. Sometimes the first letter of problem type is uppercase and sometimes is lowercase. And there are sometimes space between each data and sometimes not. My program doesn't deal with these different situations and just assume that no space between data.  
